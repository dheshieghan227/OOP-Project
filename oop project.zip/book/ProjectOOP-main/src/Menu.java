abstract class  Menu {
    abstract protected int viewMenu();
}
