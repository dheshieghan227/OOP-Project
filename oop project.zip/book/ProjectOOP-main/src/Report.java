import java.util.*;

public class Report {
    
    private Vector<OrderManagement> orderList;

    Report(Vector<OrderManagement> orderList){
        this.orderList = orderList;
    }

    Report(){}

    public void generateReport(){

    }

    public void getOrderList(){
        
    }
}
